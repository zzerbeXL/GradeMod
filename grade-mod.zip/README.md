Build: JDK 21 (use JDK 25 for Gradle itself if Loom asks for it), then `gradle wrapper && ./gradlew build`.
Jar: build/libs/grade-1.0.0.jar -> mods/ with Fabric API 0.141.x+1.21.11.
