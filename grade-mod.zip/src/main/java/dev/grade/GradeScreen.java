package dev.grade;

import java.util.EnumMap;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public final class GradeScreen extends Screen {
    private static final int W = 280, ROW = 36, PAD = 20, HEADER = 46, FOOTER = 48, R = 10;
    private final GradeSettings s = GradeSettings.get();
    private final EnumMap<GradeSettings.Param, Slider> sliders = new EnumMap<>(GradeSettings.Param.class);
    private ButtonWidget resetButton;
    private int px, py, ph;

    public GradeScreen() { super(Text.literal("Grade")); }

    /** Vanilla slider handles input (mouse, drag, arrow keys); it is invisible, we paint over it. */
    private final class Slider extends SliderWidget {
        final GradeSettings.Param p;
        Slider(int x, int y, int w, int h, GradeSettings.Param p) {
            super(x, y, w, h, Text.empty(), (s.get(p) - p.min) / (p.max - p.min));
            this.p = p;
            this.setAlpha(0f);
        }
        @Override protected void updateMessage() { setMessage(Text.empty()); }
        @Override protected void applyValue() { s.set(p, (float) (p.min + value * (p.max - p.min))); }
        double norm() { return value; }
        void sync() { value = (s.get(p) - p.min) / (p.max - p.min); }
    }

    @Override
    protected void init() {
        int n = GradeSettings.Param.values().length;
        ph = HEADER + n * ROW + FOOTER;
        px = (width - W) / 2;
        py = (height - ph) / 2;
        int i = 0;
        for (GradeSettings.Param p : GradeSettings.Param.values()) {
            Slider sl = new Slider(px + PAD, py + HEADER + i * ROW + 16, W - 2 * PAD, 14, p);
            sliders.put(p, sl);
            addDrawableChild(sl);
            i++;
        }
        resetButton = ButtonWidget.builder(Text.empty(), b -> { s.reset(); sliders.values().forEach(Slider::sync); })
            .dimensions(px + PAD, py + ph - FOOTER + 8, W - 2 * PAD, 24).build();
        resetButton.setAlpha(0f);
        addDrawableChild(resetButton);
    }

    @Override public void renderBackground(DrawContext c, int mx, int my, float d) { /* no dim/blur: the effect must stay visible */ }
    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { s.save(); }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        // panel: soft shadow, hairline border, body, white sheen
        for (int k = 5; k >= 1; k--) rr(c, px - k, py - k + 3, W + 2 * k, ph + 2 * k, R + k, a(0x10, 0x000000));
        rr(c, px - 1, py - 1, W + 2, ph + 2, R + 1, a(0x38, 0xFFFFFF));
        rr(c, px, py, W, ph, R, 0xF2101114);
        c.fillGradient(px + R, py + 1, px + W - R, py + ph / 3, a(0x16, 0xFFFFFF), a(0x00, 0xFFFFFF));
        c.fillGradient(px + R, py, px + W / 2, py + 1, a(0x00, 0xFFFFFF), a(0x90, 0xFFFFFF));
        c.fillGradient(px + W / 2, py, px + W - R, py + 1, a(0x90, 0xFFFFFF), a(0x00, 0xFFFFFF));

        c.drawText(textRenderer, Text.literal("COLOR GRADE"), px + PAD, py + 17, 0xFFFFFFFF, false);
        c.drawText(textRenderer, Text.literal("M to close"), px + W - PAD - textRenderer.getWidth("M to close"), py + 17, 0xFF6B6F78, false);
        c.fill(px + PAD, py + 34, px + W - PAD, py + 35, a(0x22, 0xFFFFFF));

        int i = 0;
        for (var e : sliders.entrySet()) {
            GradeSettings.Param p = e.getKey(); Slider sl = e.getValue();
            int y = py + HEADER + i * ROW;
            String val = p == GradeSettings.Param.TEMPERATURE ? String.format("%+.2f", s.get(p)) : String.format("%.2fx", s.get(p));
            c.drawText(textRenderer, Text.literal(p.label), px + PAD, y + 2, 0xFFC9CCD3, false);
            c.drawText(textRenderer, Text.literal(val), px + W - PAD - textRenderer.getWidth(val), y + 2, 0xFFFFFFFF, false);
            drawTrack(c, sl, sl.isHovered());
            i++;
        }

        int bx = px + PAD, by = py + ph - FOOTER + 8, bw = W - 2 * PAD;
        boolean hov = resetButton.isHovered();
        rr(c, bx, by, bw, 24, 7, a(hov ? 0x50 : 0x30, 0xFFFFFF));
        rr(c, bx + 1, by + 1, bw - 2, 22, 6, hov ? 0xFF24262C : 0xFF181A1F);
        c.fillGradient(bx + 7, by + 1, bx + bw - 7, by + 9, a(0x14, 0xFFFFFF), a(0x00, 0xFFFFFF));
        String t = "RESET";
        c.drawText(textRenderer, Text.literal(t), bx + (bw - textRenderer.getWidth(t)) / 2, by + 8, 0xFFFFFFFF, false);

        super.render(c, mx, my, delta);
    }

    private void drawTrack(DrawContext c, Slider sl, boolean hover) {
        int x = sl.getX(), w = sl.getWidth(), cy = sl.getY() + sl.getHeight() / 2;
        rr(c, x, cy - 2, w, 4, 2, 0xFF22242A);
        int kx = x + (int) Math.round(sl.norm() * w);
        int fillW = Math.max(0, kx - x);
        if (fillW >= 4) {
            rr(c, x, cy - 2, fillW, 4, 2, 0xFFE9EAEE);
            c.fillGradient(x + 2, cy - 2, x + fillW - 2, cy - 1, a(0xB0, 0xFFFFFF), a(0x00, 0xFFFFFF));
        }
        int kr = hover ? 8 : 7;
        rr(c, kx - kr - 3, cy - kr - 3, 2 * kr + 6, 2 * kr + 6, kr + 3, a(hover ? 0x30 : 0x1A, 0xFFFFFF)); // glow
        rr(c, kx - kr, cy - kr, 2 * kr, 2 * kr, kr, 0xFFFFFFFF);
        rr(c, kx - kr + 3, cy - kr + 2, 2 * kr - 6, 2 * kr - 6, kr - 3, 0xFFF1F2F5);
    }

    private static int a(int alpha, int rgb) { return (alpha << 24) | (rgb & 0xFFFFFF); }

    /** Rounded rect; corner rows get fractional-coverage edge pixels (1 GUI px AA). */
    private static void rr(DrawContext c, int x, int y, int w, int h, int r, int argb) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        c.fill(x, y + r, x + w, y + h - r, argb);
        int al = argb >>> 24, rgb = argb & 0xFFFFFF;
        for (int i = 0; i < r; i++) {
            double dy = r - (i + 0.5);
            double inset = r - Math.sqrt(Math.max(0, r * r - dy * dy));
            int full = (int) Math.ceil(inset);
            double cov = full - inset;
            int xs = x + full, xe = x + w - full;
            c.fill(xs, y + i, xe, y + i + 1, argb);
            c.fill(xs, y + h - 1 - i, xe, y + h - i, argb);
            if (cov > 0.03) {
                int edge = (((int) Math.round(al * cov)) << 24) | rgb;
                c.fill(xs - 1, y + i, xs, y + i + 1, edge);
                c.fill(xe, y + i, xe + 1, y + i + 1, edge);
                c.fill(xs - 1, y + h - 1 - i, xs, y + h - i, edge);
                c.fill(xe, y + h - 1 - i, xe + 1, y + h - i, edge);
            }
        }
    }
}
