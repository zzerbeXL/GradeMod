package dev.grade;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import java.util.EnumMap;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;

public final class GradeScreen extends Screen {
    private static final int W = 300, HEADER = 52, FOOTER = 70;
    private final GradeSettings s = GradeSettings.get();
    private final EnumMap<GradeSettings.Param, Slider> sliders = new EnumMap<>(GradeSettings.Param.class);
    private ButtonWidget resetButton;
    private int px, py, ph, row, pad = 22;
    private float k = 1f; // device pixels per GUI unit

    public GradeScreen() { super(Text.literal("Grade")); }

    /** Vanilla slider handles input (mouse, drag, arrows); it is invisible, we paint over it. */
    private final class Slider extends SliderWidget {
        final GradeSettings.Param p;
        Slider(int x, int y, int w, int h, GradeSettings.Param p) {
            super(x, y, w, h, Text.empty(), (s.get(p) - p.min) / (p.max - p.min));
            this.p = p;
            this.setAlpha(0f);
        }
        @Override protected void updateMessage() { setMessage(Text.empty()); }
        @Override protected void applyValue() { s.set(p, (float) (p.min + value * (p.max - p.min))); }
        double norm() { return value; }
        void sync() { value = (s.get(p) - p.min) / (p.max - p.min); }
    }

    @Override
    protected void init() {
        int n = GradeSettings.Param.values().length;
        row = Math.max(26, Math.min(38, (height - HEADER - FOOTER - 8) / n));
        ph = HEADER + n * row + FOOTER;
        px = (width - W) / 2;
        py = (height - ph) / 2;
        int i = 0;
        for (GradeSettings.Param p : GradeSettings.Param.values()) {
            Slider sl = new Slider(px + pad, py + HEADER + i * row + 17, W - 2 * pad, 14, p);
            sliders.put(p, sl);
            addDrawableChild(sl);
            i++;
        }
        resetButton = ButtonWidget.builder(Text.empty(), b -> { s.reset(); sliders.values().forEach(Slider::sync); })
            .dimensions(px + pad, py + ph - FOOTER + 8, W - 2 * pad, 24).build();
        resetButton.setAlpha(0f);
        addDrawableChild(resetButton);
    }

    @Override public void renderBackground(DrawContext c, int mx, int my, float d) { /* no dim/blur: the effect must stay visible */ }
    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { s.save(); }

    // ---- text (TrueType font from assets/grade/font) ----
    private static Text t(String str, boolean bold) {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("text", str);
            o.addProperty("font", bold ? "grade:ui_bold" : "grade:ui");
            return TextCodecs.CODEC.parse(JsonOps.INSTANCE, o).result().orElse(Text.literal(str));
        } catch (Throwable e) { return Text.literal(str); }
    }
    private void text(DrawContext c, String str, int x, int y, int color, boolean bold) { c.drawText(textRenderer, t(str, bold), x, y, color, false); }
    private int tw(String str, boolean bold) { return textRenderer.getWidth(t(str, bold)); }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        k = (float) client.getWindow().getScaleFactor();

        // ---- shapes: drawn in device pixels so edges are anti-aliased at 1 real px ----
        c.getMatrices().pushMatrix();
        c.getMatrices().scale(1f / k, 1f / k);
        int X = g(px), Y = g(py), PW = g(W), PH = g(ph), R = g(12);
        for (int i = 6; i >= 1; i--) rr(c, X - g(i), Y - g(i) + g(3), PW + 2 * g(i), PH + 2 * g(i), R + g(i), a(0x0C, 0x000000));
        rr(c, X - 1, Y - 1, PW + 2, PH + 2, R + 1, a(0x40, 0xFFFFFF));          // hairline border
        rr(c, X, Y, PW, PH, R, 0xF4060607);                                        // black body
        c.fillGradient(X + R, Y + 1, X + PW - R, Y + PH / 3, a(0x1A, 0xFFFFFF), a(0x00, 0xFFFFFF)); // sheen
        c.fillGradient(X + R, Y, X + PW / 2, Y + 1, a(0x00, 0xFFFFFF), a(0xA0, 0xFFFFFF));          // top highlight
        c.fillGradient(X + PW / 2, Y, X + PW - R, Y + 1, a(0xA0, 0xFFFFFF), a(0x00, 0xFFFFFF));
        c.fill(X + g(pad), Y + g(40), X + PW - g(pad), Y + g(40) + 1, a(0x26, 0xFFFFFF));

        for (Slider sl : sliders.values()) drawTrack(c, sl, sl.isHovered());

        int bx = g(px + pad), by = g(py + ph - FOOTER + 8), bw = g(W - 2 * pad), bh = g(24);
        boolean hov = resetButton.isHovered();
        rr(c, bx, by, bw, bh, g(8), a(hov ? 0x70 : 0x40, 0xFFFFFF));
        rr(c, bx + 1, by + 1, bw - 2, bh - 2, g(8) - 1, hov ? 0xFF1B1B1E : 0xFF0E0E10);
        c.fillGradient(bx + g(8), by + 1, bx + bw - g(8), by + bh / 2, a(0x18, 0xFFFFFF), a(0x00, 0xFFFFFF));
        c.getMatrices().popMatrix();

        // ---- text: GUI space, smooth TTF ----
        text(c, "COLOR GRADE", px + pad, py + 19, 0xFFFFFFFF, true);
        String hint = "M to close";
        text(c, hint, px + W - pad - tw(hint, false), py + 19, 0xFF70747C, false);
        int i = 0;
        for (var e : sliders.entrySet()) {
            GradeSettings.Param p = e.getKey();
            int y = py + HEADER + i * row;
            String val = p == GradeSettings.Param.TEMPERATURE ? String.format("%+.2f", s.get(p)) : String.format("%.2fx", s.get(p));
            text(c, p.label, px + pad, y + 2, 0xFFC8CBD2, false);
            text(c, val, px + W - pad - tw(val, true), y + 2, 0xFFFFFFFF, true);
            i++;
        }
        String r = "RESET";
        text(c, r, px + (W - tw(r, true)) / 2, py + ph - FOOTER + 16, 0xFFFFFFFF, true);
        String st = GradeRenderer.status();
        boolean err = st.startsWith("ERROR") || st.startsWith("post effect not");
        String line = "Effect: " + st;
        while (tw(line, false) > W - 2 * pad && line.length() > 8) line = line.substring(0, line.length() - 4) + "...";
        text(c, line, px + pad, py + ph - 24, err ? 0xFFFF6B6B : 0xFF70747C, false);

        super.render(c, mx, my, delta);
    }

    private int g(double guiUnits) { return (int) Math.round(guiUnits * k); }

    private void drawTrack(DrawContext c, Slider sl, boolean hover) {
        int x = g(sl.getX()), w = g(sl.getWidth()), cy = g(sl.getY() + sl.getHeight() / 2.0);
        int th = Math.max(4, g(3)), half = th / 2;
        rr(c, x, cy - half, w, th, half, 0xFF1C1C1F);
        int kx = x + (int) Math.round(sl.norm() * w);
        int fill = kx - x;
        if (fill > th) {
            rr(c, x, cy - half, fill, th, half, 0xFFEDEDEF);
            c.fillGradient(x + half, cy - half, x + fill - half, cy - half + Math.max(1, th / 3), a(0xB0, 0xFFFFFF), a(0x00, 0xFFFFFF));
        }
        int kr = g(hover ? 8 : 7);
        int glow = g(4);
        rr(c, kx - kr - glow, cy - kr - glow, 2 * (kr + glow), 2 * (kr + glow), kr + glow, a(hover ? 0x2E : 0x18, 0xFFFFFF));
        rr(c, kx - kr, cy - kr, 2 * kr, 2 * kr, kr, 0xFFFFFFFF);
        rr(c, kx - kr + g(2), cy - kr + g(2), 2 * (kr - g(2)), 2 * (kr - g(2)), kr - g(2), 0xFFE9E9EC);
    }

    private static int a(int alpha, int rgb) { return (alpha << 24) | (rgb & 0xFFFFFF); }

    /** Rounded rect in device pixels; corner edge pixels get fractional coverage. */
    private static void rr(DrawContext c, int x, int y, int w, int h, int r, int argb) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        c.fill(x, y + r, x + w, y + h - r, argb);
        int al = argb >>> 24, rgb = argb & 0xFFFFFF;
        for (int i = 0; i < r; i++) {
            double dy = r - (i + 0.5);
            double inset = r - Math.sqrt(Math.max(0, (double) r * r - dy * dy));
            int full = (int) Math.ceil(inset);
            double cov = full - inset;
            int xs = x + full, xe = x + w - full;
            c.fill(xs, y + i, xe, y + i + 1, argb);
            c.fill(xs, y + h - 1 - i, xe, y + h - i, argb);
            if (cov > 0.03) {
                int edge = (((int) Math.round(al * cov)) << 24) | rgb;
                c.fill(xs - 1, y + i, xs, y + i + 1, edge);
                c.fill(xe, y + i, xe + 1, y + i + 1, edge);
                c.fill(xs - 1, y + h - 1 - i, xs, y + h - i, edge);
                c.fill(xe, y + h - 1 - i, xe + 1, y + h - i, edge);
            }
        }
    }
}
