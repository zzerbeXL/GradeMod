package dev.grade;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class GradeClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("grade");
    private static boolean mWasDown;

    @Override
    public void onInitializeClient() {
        GradeSettings.get();
        ClientTickEvents.END_CLIENT_TICK.register(GradeClient::tick);
    }

    // Polled directly: a screen swallows key events, so a KeyBinding could not close the menu.
    private static void tick(MinecraftClient mc) {
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_M) == GLFW.GLFW_PRESS;
        if (down && !mWasDown) {
            if (mc.currentScreen instanceof GradeScreen) mc.setScreen(null);
            else if (mc.currentScreen == null && mc.world != null) mc.setScreen(new GradeScreen());
        }
        mWasDown = down;
    }
}
