package dev.grade.mixin;

import dev.grade.GradeRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    // End of world rendering: the GUI is drawn later, so the menu itself is not graded.
    @Inject(method = "renderWorld", at = @At("TAIL"))
    private void grade$apply(RenderTickCounter tickCounter, CallbackInfo ci) {
        GradeRenderer.apply(MinecraftClient.getInstance());
    }
}
