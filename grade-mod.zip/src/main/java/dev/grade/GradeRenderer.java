package dev.grade;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.grade.mixin.PostEffectPassAccessor;
import dev.grade.mixin.PostEffectProcessorAccessor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.PostEffectPass;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.util.ObjectAllocator;
import net.minecraft.util.Identifier;

public final class GradeRenderer {
    private static final Identifier EFFECT = Identifier.of("grade", "grade");
    private static final Set<Identifier> EXTERNAL = Set.of(Identifier.ofVanilla("main"));
    private static final String BLOCK = "GradeConfig";

    private static PostEffectProcessor uploadedTo;
    private static int uploadedVersion = -1;
    private static boolean failed;

    private GradeRenderer() {}

    public static void apply(MinecraftClient mc) {
        if (failed) return;
        GradeSettings s = GradeSettings.get();
        if (s.isNeutral()) return;
        try {
            PostEffectProcessor p = mc.getShaderLoader().loadPostEffect(EFFECT, EXTERNAL);
            if (p == null) return; // not (yet) loaded, e.g. during resource reload
            if (p != uploadedTo || s.version() != uploadedVersion) {
                upload(p, s);
                uploadedTo = p;
                uploadedVersion = s.version();
            }
            p.render(mc.getFramebuffer(), ObjectAllocator.TRIVIAL);
        } catch (Throwable t) {
            failed = true; // stop spamming, keep the game alive
            GradeClient.LOG.error("grade: post effect disabled after failure", t);
        }
    }

    private static void upload(PostEffectProcessor p, GradeSettings s) {
        ByteBuffer data = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder());
        data.putFloat(s.saturation).putFloat(s.brightness).putFloat(s.contrast).putFloat(s.sharpness);
        data.putFloat(s.temperature).putFloat(0f).putFloat(0f).putFloat(0f);
        boolean wrote = false;
        for (PostEffectPass pass : ((PostEffectProcessorAccessor) p).grade$getPasses()) {
            GpuBuffer buf = ((PostEffectPassAccessor) pass).grade$getUniformBuffers().get(BLOCK);
            if (buf == null) continue;
            data.rewind();
            RenderSystem.getDevice().createCommandEncoder().writeToBuffer(buf.slice(), data);
            wrote = true;
        }
        if (!wrote) throw new IllegalStateException("uniform block " + BLOCK + " not found in post effect");
    }
}
