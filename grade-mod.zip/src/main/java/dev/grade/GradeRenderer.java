package dev.grade;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.grade.mixin.PostEffectPassAccessor;
import dev.grade.mixin.PostEffectProcessorAccessor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.PostEffectPass;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.util.ObjectAllocator;
import net.minecraft.util.Identifier;

public final class GradeRenderer {
    private static final Identifier EFFECT = Identifier.of("grade", "grade");
    private static final Set<Identifier> EXTERNAL = Set.of(Identifier.ofVanilla("main"));
    private static final String BLOCK = "GradeConfig";

    private static PostEffectProcessor uploadedTo;
    private static int uploadedVersion = -1;
    private static final Set<GpuBuffer> mine = Collections.newSetFromMap(new IdentityHashMap<>());
    private static boolean failed;
    private static volatile String status = "waiting";

    private GradeRenderer() {}

    public static String status() { return status; }

    public static void apply(MinecraftClient mc) {
        if (failed) return;
        GradeSettings s = GradeSettings.get();
        if (s.isNeutral()) { status = "idle (values are neutral)"; return; }
        try {
            PostEffectProcessor p = mc.getShaderLoader().loadPostEffect(EFFECT, EXTERNAL);
            if (p == null) { status = "post effect not loaded (shader error? see latest.log)"; return; }
            if (p != uploadedTo) { mine.clear(); uploadedTo = p; uploadedVersion = -1; }
            if (s.version() != uploadedVersion) {
                upload(p, s);
                uploadedVersion = s.version();
            }
            p.render(mc.getFramebuffer(), ObjectAllocator.TRIVIAL);
            status = "active";
        } catch (Throwable t) {
            failed = true; // stop spamming, keep the game alive
            status = "ERROR: " + t.getClass().getSimpleName() + ": " + t.getMessage();
            GradeClient.LOG.error("grade: post effect disabled after failure", t);
        }
    }

    /** Vanilla bakes uniforms at load; we swap in our own writable buffer once and rewrite it on change. */
    private static void upload(PostEffectProcessor p, GradeSettings s) {
        boolean found = false;
        for (PostEffectPass pass : ((PostEffectProcessorAccessor) p).grade$getPasses()) {
            Map<String, GpuBuffer> map = ((PostEffectPassAccessor) pass).grade$getUniformBuffers();
            GpuBuffer buf = map.get(BLOCK);
            if (buf == null) continue;
            if (!mine.contains(buf)) {
                GpuBuffer own = RenderSystem.getDevice().createBuffer(() -> "grade uniforms",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_MAP_WRITE, 32);
                map.put(BLOCK, own);
                buf.close();
                mine.add(own);
                buf = own;
            }
            try (GpuBuffer.MappedView view = RenderSystem.getDevice().createCommandEncoder().mapBuffer(buf, false, true)) {
                ByteBuffer bb = view.data().order(ByteOrder.nativeOrder());
                bb.putFloat(0, s.saturation).putFloat(4, s.brightness).putFloat(8, s.contrast).putFloat(12, s.sharpness);
                bb.putFloat(16, s.temperature).putFloat(20, 0f).putFloat(24, 0f).putFloat(28, 0f);
            }
            found = true;
        }
        if (!found) throw new IllegalStateException("uniform block " + BLOCK + " not found in post effect");
    }
}
