package dev.grade;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

public final class GradeSettings {
    public enum Param {
        SATURATION("Saturation", 0.1f, 2.0f, 1.0f),
        BRIGHTNESS("Brightness", 0.1f, 2.0f, 1.0f),
        CONTRAST("Contrast", 0.5f, 1.5f, 1.0f),
        SHARPNESS("Sharpness", 0.0f, 2.0f, 0.0f),
        TEMPERATURE("Temperature", -1.0f, 1.0f, 0.0f);

        public final String label; public final float min, max, def;
        Param(String label, float min, float max, float def) { this.label = label; this.min = min; this.max = max; this.def = def; }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("grade.json");
    private static GradeSettings instance;

    public float saturation = 1f, brightness = 1f, contrast = 1f, sharpness = 0f, temperature = 0f;
    private transient int version;

    public static GradeSettings get() {
        if (instance == null) {
            GradeSettings loaded = null;
            try (Reader r = Files.newBufferedReader(FILE)) { loaded = GSON.fromJson(r, GradeSettings.class); }
            catch (Exception ignored) { /* first run or unreadable file: defaults */ }
            instance = loaded != null ? loaded : new GradeSettings();
            instance.clampAll();
        }
        return instance;
    }

    public float get(Param p) {
        return switch (p) {
            case SATURATION -> saturation; case BRIGHTNESS -> brightness; case CONTRAST -> contrast;
            case SHARPNESS -> sharpness; case TEMPERATURE -> temperature;
        };
    }

    public void set(Param p, float v) {
        v = Math.max(p.min, Math.min(p.max, v));
        switch (p) {
            case SATURATION -> saturation = v; case BRIGHTNESS -> brightness = v; case CONTRAST -> contrast = v;
            case SHARPNESS -> sharpness = v; case TEMPERATURE -> temperature = v;
        }
        version++;
    }

    public void reset() { for (Param p : Param.values()) set(p, p.def); }
    public int version() { return version; }

    public boolean isNeutral() {
        for (Param p : Param.values()) if (Math.abs(get(p) - p.def) > 1e-4f) return false;
        return true;
    }

    private void clampAll() { for (Param p : Param.values()) set(p, get(p)); }

    public void save() {
        try (Writer w = Files.newBufferedWriter(FILE)) { GSON.toJson(this, w); }
        catch (Exception e) { GradeClient.LOG.warn("grade: cannot save config", e); }
    }
}
