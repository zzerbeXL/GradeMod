#version 330

uniform sampler2D InSampler;

layout(std140) uniform GradeConfig {
    vec4 A; // x saturation, y brightness, z contrast, w sharpness
    vec4 B; // x temperature (-1 cold .. +1 warm)
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 px = 1.0 / vec2(textureSize(InSampler, 0));
    vec3 c = texture(InSampler, texCoord).rgb;

    if (A.w > 0.0) {
        vec3 n = texture(InSampler, texCoord + vec2(px.x, 0.0)).rgb
               + texture(InSampler, texCoord - vec2(px.x, 0.0)).rgb
               + texture(InSampler, texCoord + vec2(0.0, px.y)).rgb
               + texture(InSampler, texCoord - vec2(0.0, px.y)).rgb;
        c += (c - n * 0.25) * A.w * 1.5;
    }

    c = (c - 0.5) * A.z + 0.5;                       // contrast
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, A.x);                        // saturation
    c *= vec3(1.0 + 0.25 * B.x, 1.0 + 0.04 * B.x, 1.0 - 0.25 * B.x); // temperature
    c *= A.y;                                        // brightness last: 0.1 is truly dark

    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
